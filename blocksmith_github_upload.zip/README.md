# BLOCKSMITH — Minecraft Circle Generator

A standalone, browser-based Minecraft circle blueprint generator.

## Run locally
Open `index.html` in a modern web browser. No build tools, packages, or server are required.

## Publish with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. Wait for GitHub Pages to publish the site; the URL will appear in the Pages section.
